/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.faces.context.FacesContext;

/**
 *
 * @author paata
 */
@Named(value = "login")
@SessionScoped
public class Login implements Serializable {

    private String id;
    private String password;
    private Options theLoggedInAccount;

    public Options getTheLoggedInAccount() {
        return theLoggedInAccount;
    }

    public void setTheLoggedInAccount(Options theLoggedInAccount) {
        this.theLoggedInAccount = theLoggedInAccount;
    }

    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    
    
    public String login() 
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return ("Internal Error! Please try again later.");
        }
        final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/tannap3895?useSSL=false";
        
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        
        try
        {
            conn = DriverManager.getConnection(DB_URL, "tannap3895","1762909");
            st = conn.createStatement();
            rs = st.executeQuery("Select * from useraccount where id = '" + id + "'");
            if(rs.next())
            {
                if(rs.getString(3).equals(password))
                {
                    String dt = DateAndTime.DateTime();
                    theLoggedInAccount = new Options(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5),rs.getString(6),rs.getString(7),rs.getInt(8),rs.getString(9),rs.getString(10),rs.getString(11));
                    int r = st.executeUpdate("update useraccount set timeStamp = '" + dt + "' where id = '" + id + "'");
                    return ("Welcome");
                }
                else
                {
                    id = "";
                    password = "";
                    return ("IncorrectPassword");
                }
            }
            else
            {
                id="";
                password="";
                return ("UsernameNotExist");
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            return ("Internal Error!");
        }
        finally
        {
            try
            {
                rs.close();
                st.close();
                conn.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
    }
    
    public String signOut()
    {
        FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
        return "index.xhtml";
    }
    
}
