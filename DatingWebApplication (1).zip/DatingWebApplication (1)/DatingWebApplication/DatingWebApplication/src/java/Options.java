/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


/**
 *
 * @author paata
 */

public class Options implements Serializable {
    
    //this is for managed bean
    private String id;
    private String name;
    private String password;
    private String gender;
    private int age;
    private String city;
    private String interest;
    private int viewCount;
    private String interest2;
    private String interest3;
    private String timeStamp;
    

    public Options(String id, String name, String password, String gender, int age, String city, String interest, int viewCount, String interest2, String interest3, String timeStamp) {
        this.id = id;
        this.name = name;
        this.password = password;
        this.gender = gender;
        this.age = age;
        this.city = city;
        this.interest = interest;
        this.viewCount = viewCount;
        this.interest2 = interest2;
        this.interest3 = interest3;
        this.timeStamp = timeStamp;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getInterest() {
        return interest;
    }

    public void setInterest(String interest) {
        this.interest = interest;
    }

    public int getViewCount() {
        return viewCount;
    }

    public void setViewCount(int viewCount) {
        this.viewCount = viewCount;
    }

    public String getInterest2() {
        return interest2;
    }

    public void setInterest2(String interest2) {
        this.interest2 = interest2;
    }

    public String getInterest3() {
        return interest3;
    }

    public void setInterest3(String interest3) {
        this.interest3 = interest3;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    
    //this is for input values for search
    private String nameIn;
    private String gend;
    private int minAge;
    private int maxAge;
    private String interestIn;
    private String cityIn;
    private String view;

    public String getView() {
        return view;
    }

    public void setView(String view) {
        this.view = view;
    }

    public String getNameIn() {
        return nameIn;
    }

    public void setNameIn(String nameIn) {
        this.nameIn = nameIn;
    }
    
    
    
    public String getGend() {
        return gend;
    }

    public void setGend(String gend) {
        this.gend = gend;
    }

    public int getMinAge() {
        return minAge;
    }

    public void setMinAge(int minAge) {
        this.minAge = minAge;
    }

    public int getMaxAge() {
        return maxAge;
    }

    public void setMaxAge(int maxAge) {
        this.maxAge = maxAge;
    }

    public String getInterestIn() {
        return interestIn;
    }

    public void setInterestIn(String interestIn) {
        this.interestIn = interestIn;
    }

    public String getCityIn() {
        return cityIn;
    }

    public void setCityIn(String cityIn) {
        this.cityIn = cityIn;
    }

    
    
    public String addFriend(Profile userToAdd)
    {
        String pending = "pending";
        String accepted = "accepted";
        String dt = DateAndTime.DateTime();
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return ("Internal Error! Please try again later.");
        }
        final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/tannap3895?useSSL=false";
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        try
        {
            conn = DriverManager.getConnection(DB_URL,"tannap3895","1762909");
            st = conn.createStatement();
            rs = st.executeQuery("select * from friends where (Sender = '" + id + "' and Receiver = '" + userToAdd.getId() + "') or (Sender = '" + userToAdd.getId() + "' and Receiver = '" + id + "')");
            if(rs.next())
            {
                if(rs.getString(3).equals(accepted))
                {
                    return ("You already friends with this user.");
                }
                else
                {
                    if(rs.getString(1).equals(id))
                    {
                        return ("You already sent request to this user.");
                    }
                    else
                    {
                        return ("This user already sent request to you.");
                    }
                }
            }
            else
                
            {
                int r = st.executeUpdate("insert into friends values ('" + id + "', '" + userToAdd.getId() + "', '" + pending + "', '" + dt + "')");
                return ("Your request sent successfully");
            }
        }
        
        catch(SQLException e)
        {
            e.printStackTrace();
            return ("Internal Error! Please try again later.");
        }
        finally
        {
            try
            {
                rs.close();
                st.close();
                conn.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
    }
    
    public String acceptFriend(Profile requestToAccept)
    {
        String pending = "pending";
        String accepted = "accepted";
        String dt = DateAndTime.DateTime();
        //String id1 = requestToAccept.getId();
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return ("Internal Error!");
        }
        final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/tannap3895?useSSL=false";
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        try
        {
            conn = DriverManager.getConnection(DB_URL,"tannap3895","1762909");
            st = conn.createStatement();
            rs = st.executeQuery("Select * from friends where Sender = '" + requestToAccept.getId() + "' and Receiver = '" + id + "' and Status = '" + pending + "'");
            if(rs.next())
            {
                int r = st.executeUpdate("update friends set Status = '" + accepted + "', TimeStamp = '" + dt + "' where Sender = '" + requestToAccept.getId() + "' and Receiver = '" + id + "'");
                
            }
            return ("You are now friends with this user.");
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            return ("Internal Error! Please try again later.");
        }
        finally
        {
            try
            {
                rs.close();
                st.close();
                conn.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
    }
    
    public String rejectFriend(Profile requestToDelete)
    {
        String pending = "pending";
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return ("Internal Error! Please try again later.");
        }
        final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/tannap3895?useSSL=false";
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        try
        {
            conn = DriverManager.getConnection(DB_URL,"tannap3895","1762909");
            st = conn.createStatement();
            rs = st.executeQuery("Select * from friends where Sender = '" + requestToDelete.getId() + "' and Receiver = '" + id + "' and Status = '" + pending + "'");
            if(rs.next())
            {
                int r = st.executeUpdate("delete from friends where Sender = '" + requestToDelete.getId() + "' and Receiver = '" + id + "' and Status = '" + pending + "'");
                
            }
            return ("You rejected friend request from this user.");
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            return ("Internal Error! Please try again later.");
        }
        finally
        {
            try
            {
                rs.close();
                st.close();
                conn.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
    }
    
    public ArrayList<String> friendlist()
    {
        ArrayList<String> friendList = new ArrayList<>();
        String accepted = "accepted";
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
            
        }
        final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/tannap3895?useSSL=false";
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        
        try
        {
            conn = DriverManager.getConnection(DB_URL, "tannap3895", "1762909");
            st = conn.createStatement();
            rs = st.executeQuery("select * from friends where (sender = '" + id + "' or receiver = '" + id + "') and status = '" + accepted + "'");
            while(rs.next())
            {
                if(rs.getString(1).equals(id))
                {
                    friendList.add(rs.getString(2));
                }
                else 
                {
                    friendList.add(rs.getString(1));
                }
            }
        }
        
        catch(SQLException e)
        {
            e.printStackTrace();
            
        }
        finally
        {
            try
            {
                rs.close();
                st.close();
                conn.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        return friendList;
    }

    
    public ArrayList<String> friendrequest()
    {
        ArrayList<String> requests = new ArrayList<>();
        String pending = "pending";
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
            
        }
        final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/tannap3895?useSSL=false";
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        
        try
        {
            conn = DriverManager.getConnection(DB_URL, "tannap3895", "1762909");
            st = conn.createStatement();
            rs = st.executeQuery("select * from friends where receiver = '" + id + "' and status = '" + pending + "'");
            while(rs.next())
            {
                requests.add(rs.getString(1));
            }
            
        }
        
        catch(SQLException e)
        {
            e.printStackTrace();
            
        }
        finally
        {
            try
            {
                rs.close();
                st.close();
                conn.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        return requests;
    }
    
    public ArrayList<String> search()
    {
        
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        ArrayList<String> search = new ArrayList<>();
        final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/tannap3895?useSSL=false";
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        try
        {
            conn = DriverManager.getConnection(DB_URL,"tannap3895","1762909");
            st = conn.createStatement();
            rs = st.executeQuery("Select * from UserAccount where gender = '" + gend + "' and (age between '" + minAge + "' and '" + maxAge + "') and city = '" + cityIn +
                                    "' and (interest = '" + interestIn + "' or interest2 = '" + interestIn + "' or interest3 = '" + interestIn + "') and id != '" + id + "'");
            
            while(rs.next())
            {
                search.add(rs.getString(1) + ": " + rs.getString(2));
            }
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                rs.close();
                st.close();
                conn.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        return search;
    }
    
    private Profile profiles;
    private String ID;

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }
    public Profile getProfiles() {
        return profiles;
    }

    public void setProfiles(Profile profiles) {
        this.profiles = profiles;
    }
    
    

    public String viewProfile(String obj)
    {
        int index = obj.indexOf(":");
        ID = obj.substring(0,index);
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/tannap3895?useSSL=false";
        try
        {
            conn = DriverManager.getConnection(DB_URL, "tannap3895","1762909");
            st = conn.createStatement();
            rs = st.executeQuery("select * from useraccount where id ='" + ID + "'");
            //profiles.clear();
            if(rs.next() && rs.getString(1).equals(ID))
            {
                profiles = new Profile(rs.getString(1), rs.getString(2),rs.getString(4),rs.getString(6),rs.getString(7),rs.getString(9),rs.getString(10));
                int r = st.executeUpdate("Update useraccount set viewCount = viewCount+1 where id = '" + ID + "'");
            }
            

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                rs.close();
                st.close();
                conn.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }

        return "viewProfile";         
    }

    public ArrayList<String> searchByName()
    {
        ArrayList<String> searchByName = new ArrayList<>();
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/tannap3895?useSSL=false";
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        try
        {
            conn = DriverManager.getConnection(DB_URL,"tannap3895","1762909");
            st = conn.createStatement();
            rs = st.executeQuery("Select * from useraccount where name = '" + nameIn + "'");
            while(rs.next())
            {
                searchByName.add(rs.getString(1) + ": " + rs.getString(2));
            }
            if(searchByName.isEmpty())
                System.out.println("No such users found");
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                rs.close();
                st.close();
                conn.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        return searchByName;
    }
    private Profile user;

    public Profile getUser() {
        return user;
    }

    public void setUser(Profile user) {
        this.user = user;
    }
    
    public String checkProfile(String obj)
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/tannap3895?useSSL=false";
        try
        {
            conn = DriverManager.getConnection(DB_URL, "tannap3895","1762909");
            st = conn.createStatement();
            rs = st.executeQuery("select * from useraccount where id ='" + obj + "'");
            //profiles.clear();
            if(rs.next() && rs.getString(1).equals(obj))
            {
                user = new Profile(rs.getString(1), rs.getString(2),rs.getString(4),rs.getString(6),rs.getString(7),rs.getString(9),rs.getString(10));
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                rs.close();
                st.close();
                conn.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }

        return "checkProfile";         
    }
    
    public ArrayList<String> requestsent()
    {
        ArrayList<String> requestsent = new ArrayList<>();
        String pending = "pending";
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
            
        }
        final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/tannap3895?useSSL=false";
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        
        try
        {
            conn = DriverManager.getConnection(DB_URL, "tannap3895", "1762909");
            st = conn.createStatement();
            rs = st.executeQuery("select * from friends where sender = '" + id + "' and status = '" + pending + "'");
            while(rs.next())
            {
                requestsent.add(rs.getString(2));
            }
        }
        
        catch(SQLException e)
        {
            e.printStackTrace();
            
        }
        finally
        {
            try
            {
                rs.close();
                st.close();
                conn.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        return requestsent;
    }
    
    public String cancelRequest(String obj)
    {
        String pending = "pending";
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return ("Internal Error!");
        }
        final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/tannap3895?useSSL=false";
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        
        try
        {
            conn = DriverManager.getConnection(DB_URL, "tannap3895", "1762909");
            st = conn.createStatement();
            rs = st.executeQuery("select * from friends where sender = '" + id + "' and receiver = '" + obj + "' and status = '" + pending + "'");
            if(rs.next())
            {
                int r = st.executeUpdate("delete from friends where sender = '" + id + "' and receiver = '" + obj + "' and status = '" + pending + "'");
            }
        }
        
        catch(SQLException e)
        {
            e.printStackTrace();
            return ("Internal Error!");
        }
        finally
        {
            try
            {
                rs.close();
                st.close();
                conn.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        return "requestCanceled";
    }
    
    
    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    
    
    
    public String sendMessage()
    {
        String dt = DateAndTime.DateTime();
        String unread = "unread";
        String accepted = "accepted";
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return ("Internal Error!");
        }
        final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/tannap3895?useSSL=false";
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        try
        {
            conn = DriverManager.getConnection(DB_URL, "tannap3895", "1762909");
            st = conn.createStatement();
            rs = st.executeQuery("Select * from friends where (Sender = '" + id + "' and Receiver = '" + rid + "') or (Sender = '" + rid + "' and Receiver = '" + id + "') and status = '" + accepted + "'");
            if(rs.next())
            {
                int r = st.executeUpdate("insert into messages values ( '" + id + "', '" + rid + "', '" + message + "', '" + unread + "', '" + dt + "')");
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            return ("Internal Error!");
        }
        finally
        {
            try
            {
                rs.close();
                st.close();
                conn.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        viewMessages(rid);
        return "chat.xhtml";
    }
    
    
    
    private String rid;

    public String getRid() {
        return rid;
    }

    public void setRid(String rid) {
        this.rid = rid;
    }
    private ArrayList<String> messages = new ArrayList<>();

    public ArrayList<String> getMessages() {
        return messages;
    }

    public void setMessages(ArrayList<String> messages) {
        this.messages = messages;
    }
    
    public String viewMessages(String rid)
    {
        messages.clear();
        this.rid = rid;
        String read = "read";
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        try
        {
            final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/tannap3895?useSSL=false";
            conn = DriverManager.getConnection(DB_URL, "tannap3895", "1762909");
            st = conn.createStatement();

            rs = st.executeQuery("Select * from messages "
                    + "where senderID = '" + id + "' and receiverID = '"
                    + rid + "' or senderID = '" + rid + "' and  receiverID = '"
                    + id +  "'");
            while (rs.next())
            {
                messages.add(rs.getString(1) + ": " + rs.getString(3));
            }
            if(messages.isEmpty()){
                return "chat.xhtml";
            }
            else
            {
                int r = st.executeUpdate("update messages set status = '" + read + "' where senderID = '" + rid + "' and receiverID = '" + id + "'");
                return "chat.xhtml";
            }
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                rs.close();
                st.close();
                conn.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        
        return "chat.xhtml";
    }
    
    private ArrayList<String> top3Males = new ArrayList<>();

    public ArrayList<String> getTop3Males() {
        return top3Males;
    }

    public void setTop3Males(ArrayList<String> top3Males) {
        this.top3Males = top3Males;
    }
    
    
    
    public String top3Males()
    {
        String male = "male";
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/tannap3895?useSSL=false";
        try
        {
            conn = DriverManager.getConnection(DB_URL, "tannap3895","1762909");
            st = conn.createStatement();
            rs = st.executeQuery("Select * from useraccount where gender = '" + male + "' order by viewCount desc limit 3");
            while(rs.next())
            {
                top3Males.add(rs.getString(1) + ": " + rs.getString(2));
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                rs.close();
                st.close();
                conn.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        return "male.xhtml";
    }
    
    
    private ArrayList<String> top3Females = new ArrayList<>();

    public ArrayList<String> getTop3Females() {
        return top3Females;
    }

    public void setTop3Females(ArrayList<String> top3Females) {
        this.top3Females = top3Females;
    }
    
    public String top3Females()
    {
        String female = "female";
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/tannap3895?useSSL=false";
        try
        {
            conn = DriverManager.getConnection(DB_URL, "tannap3895","1762909");
            st = conn.createStatement();
            rs = st.executeQuery("Select * from useraccount where gender = '" + female + "' order by viewCount desc limit 3");
            while(rs.next())
            {
                top3Females.add(rs.getString(1) + ": " + rs.getString(2));
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                rs.close();
                st.close();
                conn.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        return "female.xhtml";
    }
    
}
