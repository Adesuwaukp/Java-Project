/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.Serializable;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;

/**
 *
 * @author paata
 */
@Named(value = "profile")
@RequestScoped
public class Profile implements Serializable
{

    
    public Profile(){} 
    private String id;
    private String nameIn;
    private String gender;
    private String cityIn;
    private String interest;
    private String interest2;
    private String interest3;

    public Profile(String id, String nameIn, String gender, String cityIn, String interest, String interest2, String interest3) {
        this.id = id;
        this.nameIn = nameIn;
        this.gender = gender;
        this.cityIn = cityIn;
        this.interest = interest;
        this.interest2 = interest2;
        this.interest3 = interest3;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

   

    public String getNameIn() {
        return nameIn;
    }

    public void setNameIn(String nameIn) {
        this.nameIn = nameIn;
    }

    public String getCityIn() {
        return cityIn;
    }

    public void setCityIn(String cityIn) {
        this.cityIn = cityIn;
    }
    
    

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

   

    public String getInterest() {
        return interest;
    }

    public void setInterest(String interest) {
        this.interest = interest;
    }

    public String getInterest2() {
        return interest2;
    }

    public void setInterest2(String interest2) {
        this.interest2 = interest2;
    }

    public String getInterest3() {
        return interest3;
    }

    public void setInterest3(String interest3) {
        this.interest3 = interest3;
    }
    
    
}
