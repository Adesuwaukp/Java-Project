/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.bean.ManagedBean;

/**
 *
 * @author paata
 */
@ManagedBean
@Named(value = "registration")
@RequestScoped
public class Registration 
{
    private String id;
    private String name;
    private String password;
    private String gender;
    private int age;
    private String city;
    private String interest;
    private String interest2;
    private String interest3;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getInterest() {
        return interest;
    }

    public void setInterest(String interest) {
        this.interest = interest;
    }

    public String getInterest2() {
        return interest2;
    }

    public void setInterest2(String interest2) {
        this.interest2 = interest2;
    }

    public String getInterest3() {
        return interest3;
    }

    public void setInterest3(String interest3) {
        this.interest3 = interest3;
    }
    
    
    public String register()
    {
        int view = 0;
        String dt = DateAndTime.DateTime();
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            return ("Driver error");
        }
        final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/tannap3895?useSSL=false";
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        
        try
        {
            
            conn = DriverManager.getConnection(DB_URL,"tannap3895","1762909");
            st = conn.createStatement();
            rs = st.executeQuery("Select * from useraccount where id ='" + id + "'");
            if(rs.next())
            {
                return ("Username already exists");
            }
            else
            {
                int r = st.executeUpdate("insert into useraccount values ('" + id + "', '" + name + "', '" + password + "', '" + gender + "', '" + age + "', '" + city + "', '" + interest + "', '" + view + "', '" + interest2 + "', '" + interest3 + "', '" + dt + "')");
                return ("Registration Successful");
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            return ("Internal error");
        }
        finally
        {
            try
            {
                rs.close();
                st.close();
                conn.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
    }
    
}
